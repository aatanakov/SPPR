from django.shortcuts import render
from django.http import HttpResponse
from .models import Unit
from .forms import UnitForm

import numpy as np
import pandas as pd
import math
import json
import time
from sklearn.model_selection import train_test_split
import scipy.sparse
from scipy.sparse import csr_matrix
import warnings; warnings.simplefilter('ignore')
import matplotlib.pyplot as plt
import seaborn as sns
from surprise import Dataset,Reader
import pickle
from sklearn.metrics.pairwise import cosine_similarity

def prediction_books(uid):
	model = pickle.load(open('media/model.sav', 'rb'))
	ratings = pd.read_csv('media/BX-Book-Ratings.csv', sep=';', error_bad_lines=False, encoding="latin-1",warn_bad_lines=False)
	ratings.columns = ['userID', 'ISBN', 'bookRating']
	books = pd.read_csv("media/BX-Books.csv", sep=";", error_bad_lines=False, encoding="latin-1",warn_bad_lines=False);
	books.columns = ['ISBN', 'bookTitle', 'bookAuthor', 'yearOfPublication', 'publisher', 'imageUrlS', 'imageUrlM', 'imageUrlL'];
	users = pd.read_csv('media/BX-Users.csv', sep=';', error_bad_lines=False, encoding="latin-1",warn_bad_lines=False);
	users.columns = ['userID', 'Location', 'Age'];
	ratings_new = ratings[ratings.ISBN.isin(books.ISBN)]
	ratings_new = ratings_new[ratings.userID.isin(users.userID)]
	ratings_explicit = ratings_new[ratings_new.bookRating != 0]
	counts1 = pd.value_counts(ratings_explicit['userID'])
	ratings_explicit = ratings_explicit[ratings_explicit['userID'].isin(counts1[counts1 >= 500].index)]
	from surprise import Dataset,Reader
	reader = Reader(rating_scale=(1, 10))
	data = Dataset.load_from_df(ratings_explicit[['userID', 'ISBN', 'bookRating']], reader)
	reader = Reader(rating_scale=(1, 10))
	data = Dataset.load_from_df(ratings_explicit[['userID', 'ISBN', 'bookRating']], reader)
	from surprise.model_selection import train_test_split
	trainset, testset = train_test_split(data, test_size=.25,random_state=123)
	test_pred=model.test(testset)
	pred = pd.DataFrame(test_pred)
	pred1 = pred[['uid', 'iid', 'r_ui']]
	books1 = books[['ISBN', 'bookTitle', 'bookAuthor']]
	books1.columns = ['iid', 'bookTitle', 'bookAuthor']
	df = pd.merge(pred1, books1, on='iid')
	return str(uid) + "::" + str(df[df['uid'] == uid][['bookTitle', 'bookAuthor']].head(10))


def beginning_books():
	model = pickle.load(open('media/model.sav', 'rb'))
	ratings = pd.read_csv('media/BX-Book-Ratings.csv', sep=';', error_bad_lines=False, encoding="latin-1",warn_bad_lines=False)
	ratings.columns = ['userID', 'ISBN', 'bookRating']
	books = pd.read_csv("media/BX-Books.csv", sep=";", error_bad_lines=False, encoding="latin-1",warn_bad_lines=False);
	books.columns = ['ISBN', 'bookTitle', 'bookAuthor', 'yearOfPublication', 'publisher', 'imageUrlS', 'imageUrlM', 'imageUrlL'];
	users = pd.read_csv('media/BX-Users.csv', sep=';', error_bad_lines=False, encoding="latin-1",warn_bad_lines=False);
	users.columns = ['userID', 'Location', 'Age'];
	ratings_new = ratings[ratings.ISBN.isin(books.ISBN)]
	ratings_new = ratings_new[ratings.userID.isin(users.userID)]
	ratings_explicit = ratings_new[ratings_new.bookRating != 0]
	counts1 = pd.value_counts(ratings_explicit['userID'])
	ratings_explicit = ratings_explicit[ratings_explicit['userID'].isin(counts1[counts1 >= 500].index)]
	pred1 = ratings_explicit
	books1 = books[['ISBN', 'bookTitle', 'bookAuthor']]
	df = pd.merge(pred1, books1, on='ISBN')
	res = []
	for i in range(10):
		uid = np.random.choice(list(np.unique(df['userID'].values)))
		res.append(str(uid) + "::" + str(df[df['userID'] == uid][['bookTitle', 'bookAuthor']].head(10)))
	return res

def index(request):
	return render(request, 'system/index.html')
	

def recom(request):
	work = Unit.objects.order_by('-user_id')
	if work:
		for n in work:
			if n.recomendations=="NULL":
				n.recomendations = prediction_books(n.user_id)
				n.save()
	return render(request, 'system/recom.html', {'work':work})
	

def post(request):
	ex = beginning_books()
	error = ''
	if request.method == 'POST':
		form = UnitForm(request.POST)

		if form.is_valid():
			form.save()
		else:
			error = 'Ошибка заполнения'
			
	form = UnitForm()
	data = {
		'form': form,
		'error': error,
		'ex': ex
	}
	return render(request, 'system/post.html', data)
